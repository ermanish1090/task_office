<!DOCTYPE html>
<?php include('./admin/connection.php')?>
<html>
<head>
	<meta charset="utf-8">
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
	    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
	    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
	    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="preconnect" href="https://fonts.googleapis.com">
		<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
		<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">	
		<link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css" />

        <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
        <link rel="stylesheet" href="css/style.css">
	<title></title>
</head>
<body>
	<div class="main-wrap">
		<div class="header">
			<div class="header-wrap">
				<div class="header-left">
				<?php 
                $query="select * from logo";
                $result=mysqli_query($conn,$query);
                while($row=mysqli_fetch_assoc($result))
                {
                    ?>
					<img src="./admin/upload/<?php echo $row['image']; ?>"style="width:150px; height:80px;">
					<?php
				}
				?>
				</div>
				<div class="header-mdl">
					<ul class="main-ul mb-0">
						<li class="menu-item explore-btn"><a href="#">Explore Program</a>
							<ul class="drop-menu">
								<li class="drop-menu-item">Content 1</li>
								<li class="drop-menu-item">Content 1</li>
							</ul>
						</li>
						<?php 
						$a=1;
						$query="select * from nav_links";
						$result=mysqli_query($conn,$query);
						while($row=mysqli_fetch_assoc($result))
						{
					   ?>
						<li>
							<a href="<?php echo $row['links_create'];?>"><?php echo $row['links_name']; ?></a>
						</li>
						<?php
                }
              $a++;
               ?>
					</ul>
				</div>
				<div class="header-right">
					<a href="./admin/index.php">Login</a>
				</div>
			</div>
		</div>
		<div class="banner-sec">
			<div class="swiper mySwiper1">
				
				<div class="swiper-wrapper">
				<?php 
                $a=1;
                $query="select * from slider";
                $result=mysqli_query($conn,$query);
                while($row=mysqli_fetch_assoc($result))
                {
               ?>
					<div class="swiper-slide">
						<div class="banner-wrap">
							<div class="banner-left-sec">
								<span><?php echo $row['headingtop'];?></span>
								<h3><?php echo $row['heading'];?></h3>
								<p><?php echo $row['paragraph'];?></p>
								<div class="banner-btn d-flex">
									<a href="<?php echo $row['links_create'];?>"><?php echo $row['links_name'];?> <i class="fa-solid fa-arrow-right"></i></a>
								</div>
							</div>
							<div class="banner-rgt-sec">
								<img src="./admin/upload/<?php echo $row['image']; ?>">
							</div>
						</div>
					</div>
					<?php
                }
              $a++;
               ?>
        </div>
				</div>
				<div class="swiper-button-next"></div>
			    <div class="swiper-button-prev"></div>
			    <div class="swiper-pagination"></div>
			</div>
		</div>
		<div class="cource-tab-sec">
			<div class="container">
				<h3>Our Courses</h3>
					<div class="cource-tab-wrap">
						<ul class="nav nav-tabs" id="myTab" role="tablist">
						  <li class="nav-item" role="presentation">
						    <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home" type="button" role="tab" aria-controls="home" aria-selected="true">For Working Professionals</button>
						  </li>
						  <li class="nav-item" role="presentation">
						    <button class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button" role="tab" aria-controls="profile" aria-selected="false">Masters</button>
						  </li>
						  <li class="nav-item" role="presentation">
						    <button class="nav-link" id="contact-tab" data-bs-toggle="tab" data-bs-target="#contact" type="button" role="tab" aria-controls="contact" aria-selected="false">Doctorate</button>
						  </li>
						  <li class="nav-item" role="presentation">
						    <button class="nav-link" id="contact-tab" data-bs-toggle="tab" data-bs-target="#contact" type="button" role="tab" aria-controls="contact" aria-selected="false">Bootcamps</button>
						  </li>
						  <li class="nav-item" role="presentation">
						    <button class="nav-link" id="contact-tab" data-bs-toggle="tab" data-bs-target="#contact" type="button" role="tab" aria-controls="contact" aria-selected="false">Study Abroad</button>
						  </li>
						  <li class="nav-item" role="presentation">
						    <button class="nav-link" id="contact-tab" data-bs-toggle="tab" data-bs-target="#contact" type="button" role="tab" aria-controls="contact" aria-selected="false">For College Students</button>
						  </li>
						</ul>
						<div class="tab-content" id="myTabContent">
						  <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
						  	<div class="cource-card-wrap">
						  		<div class="cource-card-single">
						  			<div class="cource-card-upper">
						  				<div class="card-uper-img">
						  					<img src="images/cource-img-1.jpeg">
						  				</div>
						  				<div class="card-uper-text">
						  					<span>Integrated with GenAI modules</span>
						  				</div>
						  			</div>
						  			<div class="cource-card-lower">
						  				<div class="lower-first d-flex">
						  					<div class="lower-first-left">
						  						<img src="images/iiitb.webp">
						  					</div>
						  					<div class="lower-first-rgt">
						  						<span>IIIT Banglore</span>
						  					</div>
						  				</div>
						  				<div class="lower-second">
						  					<h4>Executive Post Graduate Programme in Machine Learning & AI</h4>
						  				</div>
						  				<div class="lower-third">
						  					<div class="lower-thrd-inn">
						  						<img src="images/clock.png">
						  						<span>13 Months</span>
						  					</div>
						  					<div class="lower-thrd-inn">
						  						<img src="images/people.png">
						  						<span>Carrier Mentorship Sessions(1:1)</span>
						  					</div>
						  					</div>
						  					</div>
						  					<div class="lower-four">
						  						<div class="lower-four-left">
						  							<i class="fa-solid fa-download" style="color: #196ae5;"></i>
						  							<p>SYLLABUS</p>
						  						</div>
						  						<div class="lower-four-rgt">
						  							<a href="#">VIEW PROGRAM</a>
						  						</div>
						  					</div>		
						  		</div>
						  		<div class="cource-card-single">
						  			<div class="cource-card-upper">
						  				<div class="card-uper-img">
						  					<img src="images/cource-img-2.jpeg">
						  				</div>
						  				<div class="card-uper-text">
						  					<span>Integrated with GenAI modules</span>
						  				</div>
						  			</div>
						  			<div class="cource-card-lower">
						  				<div class="lower-first d-flex">
						  					<div class="lower-first-left">
						  						<img src="images/iiitb.webp">
						  					</div>
						  					<div class="lower-first-rgt">
						  						<span>IIIT Banglore</span>
						  					</div>
						  				</div>
						  				<div class="lower-second">
						  					<h4>Executive Post Graduate Programme in Machine Learning & AI</h4>
						  				</div>
						  				<div class="lower-third">
						  					<div class="lower-thrd-inn">
						  						<img src="images/clock.png">
						  						<span>13 Months</span>
						  					</div>
						  					<div class="lower-thrd-inn">
						  						<img src="images/people.png">
						  						<span>Carrier Mentorship Sessions(1:1)</span>
						  					</div>
						  					</div>
						  					</div>
						  					<div class="lower-four">
						  						<div class="lower-four-left">
						  							<i class="fa-solid fa-download" style="color: #196ae5;"></i>
						  							<p>SYLLABUS</p>
						  						</div>
						  						<div class="lower-four-rgt">
						  							<a href="#">VIEW PROGRAM</a>
						  						</div>
						  					</div>		
						  		</div>
						  		<div class="cource-card-single">
						  			<div class="cource-card-upper">
						  				<div class="card-uper-img">
						  					<img src="images/cource-img-3.jpeg">
						  				</div>
						  				<div class="card-uper-text">
						  					<span>Integrated with GenAI modules</span>
						  				</div>
						  			</div>
						  			<div class="cource-card-lower">
						  				<div class="lower-first d-flex">
						  					<div class="lower-first-left">
						  						<img src="images/iiitb.webp">
						  					</div>
						  					<div class="lower-first-rgt">
						  						<span>IIIT Banglore</span>
						  					</div>
						  				</div>
						  				<div class="lower-second">
						  					<h4>Executive Post Graduate Programme in Machine Learning & AI</h4>
						  				</div>
						  				<div class="lower-third">
						  					<div class="lower-thrd-inn">
						  						<img src="images/clock.png">
						  						<span>13 Months</span>
						  					</div>
						  					<div class="lower-thrd-inn">
						  						<img src="images/people.png">
						  						<span>Carrier Mentorship Sessions(1:1)</span>
						  					</div>
						  					</div>
						  					</div>
						  					<div class="lower-four">
						  						<div class="lower-four-left">
						  							<i class="fa-solid fa-download" style="color: #196ae5;"></i>
						  							<p>SYLLABUS</p>
						  						</div>
						  						<div class="lower-four-rgt">
						  							<a href="#">VIEW PROGRAM</a>
						  						</div>
						  					</div>		
						  		</div>
						  	</div>
							</div>
						  <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
						  	<div class="cource-card-wrap">
						  		<div class="cource-card-single">
						  			<div class="cource-card-upper">
						  				<div class="card-uper-img">
						  					<img src="images/cource-img-2.jpeg">
						  				</div>
						  				<div class="card-uper-text">
						  					<span>Integrated with GenAI modules</span>
						  				</div>
						  			</div>
						  			<div class="cource-card-lower">
						  				<div class="lower-first d-flex">
						  					<div class="lower-first-left">
						  						<img src="images/iiitb.webp">
						  					</div>
						  					<div class="lower-first-rgt">
						  						<span>IIIT Banglore</span>
						  					</div>
						  				</div>
						  				<div class="lower-second">
						  					<h4>Executive Post Graduate Programme in Machine Learning & AI</h4>
						  				</div>
						  				<div class="lower-third">
						  					<div class="lower-thrd-inn">
						  						<img src="images/clock.png">
						  						<span>13 Months</span>
						  					</div>
						  					<div class="lower-thrd-inn">
						  						<img src="images/people.png">
						  						<span>Carrier Mentorship Sessions(1:1)</span>
						  					</div>
						  					</div>
						  					</div>
						  					<div class="lower-four">
						  						<div class="lower-four-left">
						  							<i class="fa-solid fa-download" style="color: #196ae5;"></i>
						  							<p>SYLLABUS</p>
						  						</div>
						  						<div class="lower-four-rgt">
						  							<a href="#">VIEW PROGRAM</a>
						  						</div>
						  					</div>		
						  		</div>
						  		<div class="cource-card-single">
						  			<div class="cource-card-upper">
						  				<div class="card-uper-img">
						  					<img src="images/cource-img-1.jpeg">
						  				</div>
						  				<div class="card-uper-text">
						  					<span>Integrated with GenAI modules</span>
						  				</div>
						  			</div>
						  			<div class="cource-card-lower">
						  				<div class="lower-first d-flex">
						  					<div class="lower-first-left">
						  						<img src="images/iiitb.webp">
						  					</div>
						  					<div class="lower-first-rgt">
						  						<span>IIIT Banglore</span>
						  					</div>
						  				</div>
						  				<div class="lower-second">
						  					<h4>Executive Post Graduate Programme in Machine Learning & AI</h4>
						  				</div>
						  				<div class="lower-third">
						  					<div class="lower-thrd-inn">
						  						<img src="images/clock.png">
						  						<span>13 Months</span>
						  					</div>
						  					<div class="lower-thrd-inn">
						  						<img src="images/people.png">
						  						<span>Carrier Mentorship Sessions(1:1)</span>
						  					</div>
						  					</div>
						  					</div>
						  					<div class="lower-four">
						  						<div class="lower-four-left">
						  							<i class="fa-solid fa-download" style="color: #196ae5;"></i>
						  							<p>SYLLABUS</p>
						  						</div>
						  						<div class="lower-four-rgt">
						  							<a href="#">VIEW PROGRAM</a>
						  						</div>
						  					</div>		
						  		</div>
						  		<div class="cource-card-single">
						  			<div class="cource-card-upper">
						  				<div class="card-uper-img">
						  					<img src="images/cource-img-3.jpeg">
						  				</div>
						  				<div class="card-uper-text">
						  					<span>Integrated with GenAI modules</span>
						  				</div>
						  			</div>
						  			<div class="cource-card-lower">
						  				<div class="lower-first d-flex">
						  					<div class="lower-first-left">
						  						<img src="images/iiitb.webp">
						  					</div>
						  					<div class="lower-first-rgt">
						  						<span>IIIT Banglore</span>
						  					</div>
						  				</div>
						  				<div class="lower-second">
						  					<h4>Executive Post Graduate Programme in Machine Learning & AI</h4>
						  				</div>
						  				<div class="lower-third">
						  					<div class="lower-thrd-inn">
						  						<img src="images/clock.png">
						  						<span>13 Months</span>
						  					</div>
						  					<div class="lower-thrd-inn">
						  						<img src="images/people.png">
						  						<span>Carrier Mentorship Sessions(1:1)</span>
						  					</div>
						  					</div>
						  					</div>
						  					<div class="lower-four">
						  						<div class="lower-four-left">
						  							<i class="fa-solid fa-download" style="color: #196ae5;"></i>
						  							<p>SYLLABUS</p>
						  						</div>
						  						<div class="lower-four-rgt">
						  							<a href="#">VIEW PROGRAM</a>
						  						</div>
						  					</div>		
						  		</div>
						  	</div>
							</div>
						  <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">
						  	<div class="cource-card-wrap">
						  		<div class="cource-card-single">
						  			<div class="cource-card-upper">
						  				<div class="card-uper-img">
						  					<img src="images/cource-img-2.jpeg">
						  				</div>
						  				<div class="card-uper-text">
						  					<span>Integrated with GenAI modules</span>
						  				</div>
						  			</div>
						  			<div class="cource-card-lower">
						  				<div class="lower-first d-flex">
						  					<div class="lower-first-left">
						  						<img src="images/iiitb.webp">
						  					</div>
						  					<div class="lower-first-rgt">
						  						<span>IIIT Banglore</span>
						  					</div>
						  				</div>
						  				<div class="lower-second">
						  					<h4>Executive Post Graduate Programme in Machine Learning & AI</h4>
						  				</div>
						  				<div class="lower-third">
						  					<div class="lower-thrd-inn">
						  						<img src="images/clock.png">
						  						<span>13 Months</span>
						  					</div>
						  					<div class="lower-thrd-inn">
						  						<img src="images/people.png">
						  						<span>Carrier Mentorship Sessions(1:1)</span>
						  					</div>
						  					</div>
						  					</div>
						  					<div class="lower-four">
						  						<div class="lower-four-left">
						  							<i class="fa-solid fa-download" style="color: #196ae5;"></i>
						  							<p>SYLLABUS</p>
						  						</div>
						  						<div class="lower-four-rgt">
						  							<a href="#">VIEW PROGRAM</a>
						  						</div>
						  					</div>		
						  		</div>
						  		<div class="cource-card-single">
						  			<div class="cource-card-upper">
						  				<div class="card-uper-img">
						  					<img src="images/cource-img-1.jpeg">
						  				</div>
						  				<div class="card-uper-text">
						  					<span>Integrated with GenAI modules</span>
						  				</div>
						  			</div>
						  			<div class="cource-card-lower">
						  				<div class="lower-first d-flex">
						  					<div class="lower-first-left">
						  						<img src="images/iiitb.webp">
						  					</div>
						  					<div class="lower-first-rgt">
						  						<span>IIIT Banglore</span>
						  					</div>
						  				</div>
						  				<div class="lower-second">
						  					<h4>Executive Post Graduate Programme in Machine Learning & AI</h4>
						  				</div>
						  				<div class="lower-third">
						  					<div class="lower-thrd-inn">
						  						<img src="images/clock.png">
						  						<span>13 Months</span>
						  					</div>
						  					<div class="lower-thrd-inn">
						  						<img src="images/people.png">
						  						<span>Carrier Mentorship Sessions(1:1)</span>
						  					</div>
						  					</div>
						  					</div>
						  					<div class="lower-four">
						  						<div class="lower-four-left">
						  							<i class="fa-solid fa-download" style="color: #196ae5;"></i>
						  							<p>SYLLABUS</p>
						  						</div>
						  						<div class="lower-four-rgt">
						  							<a href="#">VIEW PROGRAM</a>
						  						</div>
						  					</div>		
						  		</div>
						  		<div class="cource-card-single">
						  			<div class="cource-card-upper">
						  				<div class="card-uper-img">
						  					<img src="images/cource-img-3.jpeg">
						  				</div>
						  				<div class="card-uper-text">
						  					<span>Integrated with GenAI modules</span>
						  				</div>
						  			</div>
						  			<div class="cource-card-lower">
						  				<div class="lower-first d-flex">
						  					<div class="lower-first-left">
						  						<img src="images/iiitb.webp">
						  					</div>
						  					<div class="lower-first-rgt">
						  						<span>IIIT Banglore</span>
						  					</div>
						  				</div>
						  				<div class="lower-second">
						  					<h4>Executive Post Graduate Programme in Machine Learning & AI</h4>
						  				</div>
						  				<div class="lower-third">
						  					<div class="lower-thrd-inn">
						  						<img src="images/clock.png">
						  						<span>13 Months</span>
						  					</div>
						  					<div class="lower-thrd-inn">
						  						<img src="images/people.png">
						  						<span>Carrier Mentorship Sessions(1:1)</span>
						  					</div>
						  					</div>
						  					</div>
						  					<div class="lower-four">
						  						<div class="lower-four-left">
						  							<i class="fa-solid fa-download" style="color: #196ae5;"></i>
						  							<p>SYLLABUS</p>
						  						</div>
						  						<div class="lower-four-rgt">
						  							<a href="#">VIEW PROGRAM</a>
						  						</div>
						  					</div>		
						  		</div>
						  	</div>
						  </div>
						</div>
					</div>
				</div>
		</div>
		<div class="teacher-dtl">
			<div class="container">
				<div class="teacher-heading">
					<h3>Free Masterclasses</h3>
				</div>
				<div class="teacher-dtl-wrap">
					<!-- <div class="teacher-card">
						<div class="card-upper">
							<img src="images/card-1.jpeg">
						</div>
						<div class="card-lower">
							<h3>3rd Oct | Tue | 7:00 PM</h3>
							<p>Understand the in-demand skills required to land your dream data science role</p>
							<div class="register-btn">
								<a href="#">Register</a>
							</div>
						</div>
					</div>
					<div class="teacher-card">
						<div class="card-upper">
							<img src="images/card-2.jpeg">
						</div>
						<div class="card-lower">
							<h3>3rd Oct | Tue | 7:00 PM</h3>
							<p>Understand the in-demand skills required to land your dream data science role</p>
							<div class="register-btn">
								<a href="#">Register</a>
							</div>
						</div>
					</div>
			-->
			<?php 
						$a=1;
						$query="select * from master_class";
						$result=mysqli_query($conn,$query);
						while($row=mysqli_fetch_assoc($result))
						{
					   ?>
					<div class="teacher-card">
						<div class="card-upper">
							<img src="./admin/upload/<?php echo $row['image']; ?>">
						</div>
						<div class="card-lower">
							<h3><?php echo $row['date'];?></h3>
							<p><?php echo $row['paragraph'];?></p>
							<div class="register-btn">
								<a href="<?php echo $row['links_create'];?>"><?php echo $row['links_name'];?></a>
							</div>
						</div>
					</div>
					<?php
                }
              $a++;
               ?>
					
				</div>
			</div>
		</div>
		<div class="explore-cource">
			<div class="container">
				<h3>
					Explore Free Courses
				</h3>
				<div class="swiper mySwiper-cource">
					<div class="swiper-wrapper">
					<?php 
						$a=1;
						$query="select * from free_class";
						$result=mysqli_query($conn,$query);
						while($row=mysqli_fetch_assoc($result))
						{
							?>
						<div class="swiper-slide">
							<div class="explore-cource-card">
								<div class="cource-upper">
									<img src="./admin/upload/<?php echo $row['image']; ?>">
								</div>
								<div class="cource-lower">
									<h3>
									<?php echo $row['heading']; ?>
									</h3>
									<p>
									<?php echo $row['paragraph']; ?>
									</p>
									<div class="register-btn">
									<a href="<?php echo $row['links_create']; ?>"><?php echo $row['links_name']; ?></a>
								</div>
								</div>
							</div>
						</div>
						<?php
					}
              $a++;
               ?>
					</div>
					<div class="swiper-button-next"></div>
	    		<div class="swiper-button-prev"></div>
				</div>
			</div>
		</div>
		<div class="top-univer-wrap">
			<div class="container">
				<div class="common-head-wrap">
					<p>In partnership with</p>
					<h3>World's Top Universities</h3>
				</div>
				<div class="univer-img-wrap">
					<div class="img-wrap-top">
						<img src="images/univ-1.jpeg">
						<img src="images/univ-2.jpeg">
						<img src="images/univ-3.jpeg">
						<img src="images/univ-4.jpeg">
					</div>
					<div class="img-wrap-btm">
						<img src="images/univ-5.jpeg">
						<img src="images/univ-6.jpeg">
						<img src="images/univ-7.jpeg">
						<img src="images/univ-8.jpeg">
					</div>
				</div>
				<div class="univ-btn">
					<a href="#">VIEW MORE UNIVERSITIES</a>
				</div>
			</div>
		</div>	
		<div class="trusted-prog-sec">
			<div class="common-head-wrap text-center">
				<p>Learn Data Science from</p>
				<h3>India's Most Trusted Program</h3>
				<span>Over 25,000+ learners rated this program 4.7/5, under the guidance of 2500+ industry mentors</span>
			</div>
			<div class="trusted-prog-card-wrap">
				<div class="prog-card-single">
					<p>66%</p>
					<span>Alumni Career Transitions</span>
				</div>
				<div class="prog-card-single">
					<p class="orange">3000+</p>
					<span>Hiring Companies</span>
				</div>
				<div class="prog-card-single">
					<p class="purple">55%</p>
					<span>Avg. Salary Hike</span>
				</div>
			</div>
		</div>
		<div class="why-choose-sec text-center">
			<div class="common-head-wrap">
				<p>Here are more reasons</p>
				<h3>Why choose Great Learning courses?</h3>
			</div>
			<div class="choose-inner-sec">
				<div class="choose-inner-wrap d-flex">
					<div class="choose-inner-left">
						<img src="images/why-choose-1.jpg">
					</div>
					<div class="choose-inner-rgt">
						<h4>Get Personalized Guidance</h4>
						<p>Weekly mentorship sessions with Industry Experts along with Personalized attention in small groups of 5-15 learners. Gain hands-on exposure through industry-relevant projects</p>
						<div class="rating-wrap d-flex">
							<div class="rating-wrap-left">
								<div class="rating-img">
									<img src="images/tick.svg">
								</div>
								<span>2,00,000+</span>
								<p>Mentorship Sessions Completed</p>
							</div>
							<div class="rating-wrap-rgt">
								<div class="rating-img">
									<img src="images/star.svg">
								</div>
								<span>2,00,000+</span>
								<p>Mentorship Sessions Completed</p>
							</div>
						</div>
						<div class="experience-btn">
							<a href="#">VIEW EXPERIENCE</a>
						</div>
					</div>
				</div>
				<div class="choose-inner-wrap d-flex">
					<div class="choose-inner-rgt">
						<h4>GL Excelerate Dedicated Career Support</h4>
						<p>We offer mock interviews to prep for your dream job. Participate in hackathons and career fairs to stay ahead of others.</p>
						<div class="rating-wrap d-flex">
							<div class="rating-wrap-left">
								<div class="rating-img">
									<img src="images/fast-forward.svg">
								</div>
								<span>66%</span>
								<p>Alumni Career Transitions</p>
							</div>
							<div class="rating-wrap-rgt">
								<div class="rating-img">
									<img src="images/work-outline.svg">
								</div>
								<span>3000+</span>
								<p>Hiring Companies</p>
							</div>
						</div>
						<div class="experience-btn">
							<a href="#">LEARN MORE</a>
						</div>
					</div>
					<div class="choose-inner-left">
						<img src="images/why-choose-2.jpg">
					</div>
				</div>
				<div class="choose-inner-wrap d-flex">
					<div class="choose-inner-left">
						<img src="images/why-choose-3.png">
					</div>
					<div class="choose-inner-rgt">
						<h4>Networking and Program Support</h4>
						<p>Grow your professional network with peer interactions, sessions with industry leaders, and get access to a dedicated program manager to solve your queries.</p>
						<div class="rating-wrap d-flex">
							<div class="rating-wrap-left">
								<div class="rating-img">
									<img src="images/support.svg">
								</div>
								<span>1:1</span>
								<p>Program support</p>
							</div>
							<div class="rating-wrap-rgt">
								<div class="rating-img">
									<img src="images/star.svg">
								</div>
								<span>4.3/5</span>
								<p>Average Support Rating</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="countries-sec text-center">
			<div class="common-head-wrap text-center">
				<p>Providing online education for</p>
				<h3>Learners across 170+ countries</h3>
			</div>
			<div class="country-top-wrap">
				<img src="images/country-img.png">
			</div>
			<div class="country-bottom-wrap">
				<div class="container">
				<div class="country-cards">
					<div class="cuntry-card-wrap">
						<div class="country-cards-single">
							<a href="#" class="d-flex">
								<div class="img-txt-wrap">
									<img src="images/course-report.png">
									<p class="mb-0">CourseReport.com</p>
								</div>
								<div class="country-rating">
									4.81
									<img src="images/star.svg">
								</div>
							</a>
						</div>
						<div class="country-cards-single">
							<a href="#" class="d-flex">
								<div class="img-txt-wrap">
									<img src="images/play-store.png">
									<p class="mb-0">Google Play</p>
								</div>
								<div class="country-rating">
									4.6
									<img src="images/star.svg">
								</div>
							</a>
						</div>
					</div>
					<div class="cuntry-card-wrap">
						<div class="country-cards-single">
							<a href="#" class="d-flex">
								<div class="img-txt-wrap">
									<img src="images/blue-star.png">
									<p class="mb-0">Trustpilot.com</p>
								</div>
								<div class="country-rating">
									4.8
									<img src="images/star.svg">
								</div>
							</a>
						</div>
						<div class="country-cards-single">
							<a href="#" class="d-flex">
								<div class="img-txt-wrap">
									<img src="images/career-karma.png">
									<p class="mb-0">Career Karma</p>
								</div>
								<div class="country-rating">
									4.7
									<img src="images/star.svg">
								</div>
							</a>
						</div>
					</div>
				</div>
				</div>
			</div>
		</div>
		<div class="alumini-profile-sec">
			<h3>Our Alumni Profiles</h3>
			<div class="swiper mySwiper">
				<div class="swiper-wrapper alumini-swiper">
				<?php 
						$a=1;
						$query="select * from alumni";
						$result=mysqli_query($conn,$query);
						while($row=mysqli_fetch_assoc($result))
						{
							?>

					<div class="swiper-slide">
						<div class="alumini-card">
							<div class="alumini-img-wrap">
								<div class="alumini-person">
									<img src="./admin/upload/<?php echo $row['image']; ?>">
								</div>
								<div class="linkdin">
									<img src="images/linkedin.svg">
								</div>
							</div>
							<p><?php echo $row['name']; ?></p>
							<div class="alumini-btm-img">
								<img src="./admin/upload/<?php echo $row['image_1']; ?>">
							</div>
						</div>
					</div>
					<?php
					}
              $a++;
               ?>

				</div>
				<div class="swiper-button-next"></div>
      			<div class="swiper-button-prev"></div>
			</div>
		</div>
		<div class="footer">
			<div class="footer-wrap d-flex">
				<div class="footer-1">
					<h3>Trending Programs</h3>
					<ul>
						<li>
							<a href="#">UT Austin: PG Program in Data Science and Business Analytics</a>
						</li>
						<li>
							<a href="#">UT Austin: PG Program in Artificial Intelligence and Machine Learning</a>
						</li>
						<li>
							<a href="#">Great Lakes: PG Program in Data Science and Engineering (Bootcamp)</a>
						</li>
						<li>
							<a href="#">Great Lakes: PG Diploma in Management (Online)</a>
						</li>
						<li>
							<a href="#">Great Lakes: PG Program in Cloud Computing</a>
						</li>
					</ul>
				</div>
				<div class="footer-2">
					<h3>Browse Courses</h3>
					<ul>
						<li>
							<a href="#">Data Science Courses</a>
						</li>
						<li>
							<a href="#">Artificial Intelligence Courses</a>
						</li>
						<li>
							<a href="#">Digital Marketing Courses</a>
						</li>
						<li>
							<a href="#">Software Engineering Courses</a>
						</li>
						<li>
							<a href="#">Cloud Computing Courses</a>
						</li>
					</ul>
				</div>
				<div class="footer-3">
					<h3>Degrees</h3>
					<ul>
						<li>
							<a href="#">MBA Courses</a>
						</li>
						<li>
							<a href="#">M. Tech Courses</a>
						</li>
						<li>
							<a href="#">Masters Courses</a>
						</li>
					</ul>
					<div class="footer-inner">
						<h3>Quick Links</h3>
						<ul>
							<li>
								<a href="#">About Us</a>
							</li>
							<li>
								<a href="#">Careers at Great Learning</a>
							</li>
							<li>
								<a href="#">Grievance Redressal</a>
							</li>
							<li>
								<a href="#">Contact Us</a>
							</li>
						</ul>
					</div>
				</div>
				<div class="footer-4">
					<div class="footer-logo">
						<img src="images/fotter-white-logo.png">
					</div>
					<div class="contact-main">
						<span>India:</span>
						<div class="contact-wrap">
							<i class="fa-regular fa-envelope" style="color: #ffffff;"></i>
							<p>info@greatlearning.in</p>
						</div>
						<div class="contact-wrap">
							<i class="fa-solid fa-phone" style="color: #ffffff;"></i>
							<p>080 6947 4555</p>
						</div>
					</div>
					<div class="contact-main">
						<span>US and Other countries :</span>
						<div class="contact-wrap">
							<i class="fa-regular fa-envelope" style="color: #ffffff;"></i>
							<p>info@mygreatlearning.com</p>
						</div>
						<div class="contact-wrap">
							<i class="fa-solid fa-phone" style="color: #ffffff;"></i>
							<p>+1 512 647 2647</p>
						</div>
						<div class="footer-icon">
							<ul class="d-flex">
								<li>
									<a href="#"><i class="fa-brands fa-facebook" style="color: #ffffff;"></i></a>
								</li>
								<li>
									<a href="#"><i class="fa-brands fa-twitter" style="color: #ffffff;"></i></a>
								</li>
								<li>
									<a href="#"><i class="fa-brands fa-linkedin-in" style="color: #ffffff;"></i></a>
								</li>
								<li>
									<a href="#"><i class="fa-brands fa-youtube" style="color: #ffffff;"></i></a>
								</li>
								<li>
									<a href="#"><i class="fa-brands fa-instagram" style="color: #ffffff;"></i></a>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>





	<script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>
	<script>
    var swiper = new Swiper(".mySwiper1", {
      pagination: {
        el: ".swiper-pagination",
        type: "fraction",
      },
      navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
      },
    });
  </script>


  <script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>
  <script>
      var swiper = new Swiper(".mySwiper", {
        slidesPerView: 6,
        spaceBetween: 12,
        loop: true,
        pagination: {
          el: ".swiper-pagination",
          clickable: true
        },
        navigation: {
          nextEl: ".swiper-button-next",
          prevEl: ".swiper-button-prev"
        }
      });
    </script>

    <script>
      var swiper = new Swiper(".mySwiper-cource", {
        slidesPerView: 3,
        spaceBetween: 12,
        loop: true,
        pagination: {
          el: ".swiper-pagination",
          clickable: true
        },
        navigation: {
          nextEl: ".swiper-button-next",
          prevEl: ".swiper-button-prev"
        }
      });
    </script>
</body>
</html>