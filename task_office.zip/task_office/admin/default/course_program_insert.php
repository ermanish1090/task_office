<?php 
  include("../connection.php");
  ?>
  <?php

  if(isset($_POST['submit']))
  {
  extract($_POST);
  $file_name=$_FILES['file']['name'];
  $tmp_name=$_FILES['file']['tmp_name'];
  $location='../upload/';
  $heading=$_POST['heading'];
   $paragraph=$_POST['paragraph'];
   $place=$_POST['place'];
   $duration=$_POST['duration'];
   $session_1=$_POST['session_1'];
   $syllabus=$_POST['syllabus'];
   $program_id=$_POST['program_id'];
   $links_create=$_POST['links_create'];
   $links_name=$_POST['links_name'];
  $query="insert into course_program(image,heading,paragraph,place,session_1,duration,syllabus,program_id,links_create,links_name) 
  values('$file_name','$heading','$paragraph','$place','$session_1','$duration','$syllabus','$program_id','$links_create','$links_name')";
  mysqli_query($conn,$query);
  move_uploaded_file($tmp_name,$location.$file_name);
  echo "<script>alert('content has been added successfully');window.location.href='course_program_all';</script>";
  }
?>
