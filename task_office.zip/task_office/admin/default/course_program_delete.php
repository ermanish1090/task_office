<?php
include("../connection.php");
$id=$_REQUEST['id'];


$query="delete from course_program where id='$id'";
mysqli_query($conn,$query);
header("Location:course_program_all");

?>