<?php
 include "../connection.php";   
    session_start();
    if (!isset($_SESSION["userid"]))
    {
        header("Location:../index");
    }    
?>
<?php $page="setting"; include("header.php")?>
<!-- Main Content -->
<div class="adminx-content">
        <div class="adminx-main-content">
          <div class="container-fluid">
            <div class="pb-3">
              <h1><b><i>Company Logo</i></b></h1>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <div class="card mb-grid">
                  <div class="card-body collapse show" id="card1">
                  <form action="insert_logo" method="post" enctype="multipart/form-data">
                  <div class="card-header">
                    File upload
                  </div>
                  <div class="card-body">
                    <div class="custom-file">
                      <input type="file" class="custom-file-input" id="customFile">
                      <label class="custom-file-label" for="customFile" name="file" accept="image/png, image/jpg, image/jpeg">Choose file</label>
                    </div>
                  </div>
                </div> 
              </div>
              <button type="submit" class="btn btn-sm btn-block btn-primary" name="submit">Add Logo</button>
            </form>
            </div>
         </div>
         <script>
</script>
<?php include("footer.php")?>