<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Administor of Can Technology</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" type="text/css" href="./dist/css/adminx.css" media="screen" />
    <style>
      /* .virat{
        background-color: #A9C9FF;
        background-image: linear-gradient(180deg, #A9C9FF 0%, #FFBBEC 100%);
        height: 100%;    
        } */
      /* .virat_1{
            background-image:linear-gradient(180deg, #A9C9FF 0%, #FFBBEC 100%);
            opacity: .9;
             color: black;
             background-size: 100% 100%;
        }
      .push{
            background-image: linear-gradient(180deg, #A9C9FF 0%, #FFBBEC 100%);
            opacity: .9;
             color: black;
             background-size: 100% 100%;
             font-weight: 700;
        } */
        .pb-3{
          text-align:center;
        }
    </style>
  </head>
  <body class=" virat">
    <div class="adminx-container">
    <?php 
                $query="select * from admin_login";
                $result=mysqli_query($conn,$query);
                while($row=mysqli_fetch_assoc($result))
                {
                    ?>
      <nav class="navbar navbar-expand justify-content-between fixed-top virat_1" >
        <a class="navbar-brand mb-0 h1 d-none d-md-block" href="admin">
          <img src="../upload/<?php echo $row['image'];?>" class="navbar-brand-image d-inline-block align-top mr-2" class="circle" alt="">
        
        </a>
        <div class="d-flex flex-1 d-block d-md-none">
          <a href="#" class="sidebar-toggle ml-3">
            <i data-feather="menu"></i>
          </a>
        </div>
        <ul class="navbar-nav d-flex justify-content-end mr-2">
          <li class="nav-item dropdown">
            <a class="nav-link avatar-with-name" id="navbarDropdownMenuLink" data-toggle="dropdown" href="#">
              <img src="../upload/<?php echo $row['image'];?>" class="d-inline-block align-top"class="rounded" alt="">
            </a>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
              <a class="dropdown-item" href="admin_account">My Profile</a>
              <a class="dropdown-item" href="change_password">Change Password</a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item text-danger" href="../logout">Sign out</a>
            </div>
          </li>
        </ul>
        <?php
                }
                ?>
      </nav>
      <!-- expand-hover push -->
      <!-- Sidebar -->
      <div class="adminx-sidebar expand-hover push">
        <ul class="sidebar-nav">
          <li class="sidebar-nav-item">
            <a href="admin" class="sidebar-nav-link <?php if($page=='home'){echo'active';}?>">
              <span class="sidebar-nav-icon">
                <i data-feather="grid"></i>
              </span>
              <span class="sidebar-nav-name">
                Dashboard
              </span>
              <span class="sidebar-nav-end">

              </span>
            </a>
          </li>
         <!-- part1 Home -->
            <!-- part4  Our_Initatives -->
            <li class="sidebar-nav-item">
            <a class=" sidebar-nav-link <?php if($page=='navbar'){echo'active';}?> collapsed" data-toggle="collapse" href="#examp" aria-expanded="false" aria-controls="examp">
              <span class="sidebar-nav-icon">
                <i data-feather="pie-chart"></i>
              </span>
              <span class="sidebar-nav-name">
              Navbar
              </span>
              <span class="sidebar-nav-end">
                <i data-feather="chevron-right" class="nav-collapse-icon"></i>
              </span>
            </a>
            <ul class="sidebar-sub-nav collapse" id="examp">
              <li class="sidebar-nav-item">
                <a href="../default/navbar_add" class="sidebar-nav-link">
                  <span class="sidebar-nav-abbr">
                  <i data-feather="plus-circle"></i>
                  </span>
                  <span class="sidebar-nav-name">
                    Add Navbar
                  </span>
                </a>
              </li>
              <li class="sidebar-nav-item">
                <a href="../default/navbar_all" class="sidebar-nav-link">
                  <span class="sidebar-nav-abbr">
                    <i data-feather="edit-3"></i>
                  </span>
                  <span class="sidebar-nav-name">
                  show All Navbar
                  </span>
                </a>
              </li>
            </ul>
          </li>
          <!-- part Our_Initatives end -->
         <li class="sidebar-nav-item">
            <a class="sidebar-nav-link <?php if($page=='slider'){echo'active';}?> collapsed" data-toggle="collapse" href="#example" aria-expanded="false" aria-controls="example">
              <span class="sidebar-nav-icon">
              <i data-feather="home"></i>
              </span>
              <span class="sidebar-nav-name">
                Slider
              </span>
              <span class="sidebar-nav-end">
                <i data-feather="chevron-right" class="nav-collapse-icon"></i>
              </span>
            </a>
            <ul class="sidebar-sub-nav collapse" id="example">
           <!-- slider start -->
                <li class="sidebar-nav-item">
                <a href="../default/ad_slider" class="sidebar-nav-link">
                  <span class="sidebar-nav-abbr">
                    <i data-feather="plus-circle"></i>
                  </span>
                  <span class="sidebar-nav-name">
                    Ad_Slider
                  </span>
                </a>
              </li>
              <li class="sidebar-nav-item">
                <a href="../default/all_slider" class="sidebar-nav-link">
                  <span class="sidebar-nav-abbr">
                    <i data-feather="edit-3"></i>
                  </span>
                  <span class="sidebar-nav-name">
                    Show Slider
                  </span>
                </a>
              </li>
            </ul>
              </li>
   <!-- slider end -->
          <!-- part home end -->
           <!-- part2 About -->
          <li class="sidebar-nav-item">
            <a class=" sidebar-nav-link <?php if($page=='masster_class'){echo'active';}?> collapsed" data-toggle="collapse" href="#exampl_a" aria-expanded="false" aria-controls="exampl_a">
              <span class="sidebar-nav-icon">
              <i data-feather="user"></i>
              </span>
              <span class="sidebar-nav-name">
                Master_Class
              </span>
              <span class="sidebar-nav-end">
                <i data-feather="chevron-right" class="nav-collapse-icon"></i>
              </span>
            </a>
            <ul class="sidebar-sub-nav collapse" id="exampl_a">
              <li class="sidebar-nav-item">
                <a href="../default/class_add" class="sidebar-nav-link">
                  <span class="sidebar-nav-abbr">
                  <i data-feather="plus-circle"></i>
                  </span>
                  <span class="sidebar-nav-name">
                    Add Master_Class
                  </span>
                </a>
              </li>
              <li class="sidebar-nav-item">
                <a href=../default/class_all class="sidebar-nav-link">
                  <span class="sidebar-nav-abbr">
                    <i data-feather="edit-3"></i>
                  </span>
                  <span class="sidebar-nav-name">
                    All Master_Class
                  </span>
                </a>
              </li>
            </ul>
          </li>
          <li class="sidebar-nav-item">
            <a class=" sidebar-nav-link <?php if($page=='course'){echo'active';}?> collapsed" data-toggle="collapse" href="#exampl_ab" aria-expanded="false" aria-controls="exampl_a">
              <span class="sidebar-nav-icon">
              <i data-feather="users"></i>
              </span>
              <span class="sidebar-nav-name">
                Course
              </span>
              <span class="sidebar-nav-end">
                <i data-feather="chevron-right" class="nav-collapse-icon"></i>
              </span>
            </a>
            <ul class="sidebar-sub-nav collapse" id="exampl_ab">
              <li class="sidebar-nav-item">
                <a href="../default/course_add" class="sidebar-nav-link">
                  <span class="sidebar-nav-abbr">
                  <i data-feather="plus-circle"></i>
                  </span>
                  <span class="sidebar-nav-name">
                    Add Course
                  </span>
                </a>
              </li>
              <li class="sidebar-nav-item">
                <a href=../default/course_all class="sidebar-nav-link">
                  <span class="sidebar-nav-abbr">
                    <i data-feather="edit-3"></i>
                  </span>
                  <span class="sidebar-nav-name">
                    All Course Details
                  </span>
                </a>
              </li>
            </ul>
          </li>
          <li class="sidebar-nav-item">
            <a class=" sidebar-nav-link <?php if($page=='alumni'){echo'active';}?> collapsed" data-toggle="collapse" href="#exampl_abc" aria-expanded="false" aria-controls="exampl_a">
              <span class="sidebar-nav-icon">
              <i data-feather="zap"></i>
              </span>
              <span class="sidebar-nav-name">
                Alumni Profile
              </span>
              <span class="sidebar-nav-end">
                <i data-feather="chevron-right" class="nav-collapse-icon"></i>
              </span>
            </a>
            <ul class="sidebar-sub-nav collapse" id="exampl_abc">
              <li class="sidebar-nav-item">
                <a href="../default/alumni_add" class="sidebar-nav-link">
                  <span class="sidebar-nav-abbr">
                  <i data-feather="plus-circle"></i>
                  </span>
                  <span class="sidebar-nav-name">
                    Add Alumni Profile
                  </span>
                </a>
              </li>
              <li class="sidebar-nav-item">
                <a href=../default/alumni_all class="sidebar-nav-link">
                  <span class="sidebar-nav-abbr">
                    <i data-feather="edit-3"></i>
                  </span>
                  <span class="sidebar-nav-name">
                    All Alumni Profile
                  </span>
                </a>
              </li>
            </ul>
          </li>
          <li class="sidebar-nav-item">
            <a class=" sidebar-nav-link <?php if($page=='freeclass'){echo'active';}?> collapsed" data-toggle="collapse" href="#exampl_abcd" aria-expanded="false" aria-controls="exampl_a">
              <span class="sidebar-nav-icon">
              <i data-feather="tv"></i>
              </span>
              <span class="sidebar-nav-name">
                Free Classes
              </span>
              <span class="sidebar-nav-end">
                <i data-feather="chevron-right" class="nav-collapse-icon"></i>
              </span>
            </a>
            <ul class="sidebar-sub-nav collapse" id="exampl_abcd">
              <li class="sidebar-nav-item">
                <a href="../default/freeclass_add" class="sidebar-nav-link">
                  <span class="sidebar-nav-abbr">
                  <i data-feather="plus-circle"></i>
                  </span>
                  <span class="sidebar-nav-name">
                    Add free Classes
                  </span>
                </a>
              </li>
              <li class="sidebar-nav-item">
                <a href=../default/freeclass_all class="sidebar-nav-link">
                  <span class="sidebar-nav-abbr">
                    <i data-feather="edit-3"></i>
                  </span>
                  <span class="sidebar-nav-name">
                    All Free Classes
                  </span>
                </a>
              </li>
            </ul>
          </li>
          <!-- part about end -->
           <!-- part4  Events -->
         <!-- part News end -->
          <!-- part7  Setting -->
          <li class="sidebar-nav-item">
            <a class=" sidebar-nav-link <?php if($page=='setting'){echo'active';}?> collapsed" data-toggle="collapse" href="#ex" aria-expanded="false" aria-controls="ex">
              <span class="sidebar-nav-icon">
                <i data-feather="settings"></i>
              </span>
              <span class="sidebar-nav-name">
              Setting
              </span>
              <span class="sidebar-nav-end">
                <i data-feather="chevron-right" class="nav-collapse-icon"></i>
              </span>
            </a>
            <ul class="sidebar-sub-nav collapse" id="ex">
              <li class="sidebar-nav-item">
                <a href="../default/all_logo" class="sidebar-nav-link">
                  <span class="sidebar-nav-abbr">
                  <i data-feather="box"></i>
                   </span>
                  <span class="sidebar-nav-name">
                  Company Logo
                  </span>
                  </a>
                </li>
              <li class="sidebar-nav-item">
                <a href="../default/background" class="sidebar-nav-link">
                  <span class="sidebar-nav-abbr">
                  <i data-feather="disc"></i>
                  </span>
                  <span class="sidebar-nav-name">
                  Admin Backgound Images 
                  </span>
                  </a>
                </li>
              <!-- <li class="sidebar-nav-item">
                <a href="../default/all_social" class="sidebar-nav-link">
                  <span class="sidebar-nav-abbr">
                  <i data-feather="target"></i>
                  </span>
                  <span class="sidebar-nav-name">
                    Social 
                  </span>
                </a>
               </li>
              <li class="sidebar-nav-item">
                <a href="../default/all_footer" class="sidebar-nav-link">
                  <span class="sidebar-nav-abbr">
                  <i data-feather="target"></i>
                  </span>
                  <span class="sidebar-nav-name">
                    Footer
                  </span>
                </a>
               </li> -->
          <!-- footer -->
        </ul>
          <!-- part Setting end -->
      </div><!-- Sidebar End -->