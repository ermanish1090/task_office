<?php
 include "../connection.php";   
    session_start();
    if (!isset($_SESSION["userid"]))
    {
        header("Location:../index");
    }    
?>
<?php $page="slider";include("header.php")?>
<!-- Main Content -->
<div class="adminx-content">
        <div class="adminx-main-content">
          <div class="container-fluid">
            <div class="pb-3">
              <h1><b><i>Slider</i></b></h1>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <div class="card mb-grid">
                  <div class="card-body collapse show" id="card1">
                  <form action="insert_slider" method="post" enctype="multipart/form-data">
                      <div class="form-group">
                        <label class="form-label" for="exampleInputEmail1">TopContent</label>
                        <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Top of content " name="headingtop">
                      </div>
                      <div class="form-group">
                        <label class="form-label" for="exampleInputEmail1">Heading</label>
                        <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Heading" name="heading">
                      </div>
                      <div class="form-group">
                        <label class="form-label" for="exampleInputPassword1">SubHeading</label>
                        <input type="text" class="form-control" id="exampleInputPassword1" placeholder="Sub heading" name="paragraph">
                      </div>
                      <div class="form-group">
                        <label class="form-label" for="exampleInputPassword1">Heading Of Links</label>
                        <input type="text" class="form-control" id="exampleInputPassword1" placeholder="Heading Of Links" name="links_name">
                      </div>
                      <div class="form-group">
                        <label class="form-label" for="exampleInputPassword1">Links Create</label>
                        <input type="text" class="form-control" id="exampleInputPassword1" placeholder="Links Create" name="links_create">
                      </div>
                      <div class="form-group">
                        <label class="form-label" for="exampleInputPassword1">File Upload</label>
                        <input type="file" class="form-control" id="exampleInputPassword1" name="file" accept="image/png, image/jpg, image/jpeg">
                      </div>
                      <!-- <div class="card mb-grid">
                  <div class="card-header">
                    File upload
                  </div>
                  <div class="card-body">
                    <div class="custom-file">
                      <input type="file" class="custom-file-input" id="customFile">
                      <label class="custom-file-label" for="customFile">Choose file</label>
                    </div>
                  </div>
                </div> 
              </div> -->
              <button type="submit" class="btn btn-sm btn-block btn-primary" name="submit">Add Slider</button>
            </form>
            </div>
         </div>
         <script>
    
document.getElementById("name").onkeypress = function(e) {
    var chr = String.fromCharCode(e.which);
    if ("></\"=".indexOf(chr) >= 0)
        return false;
};
document.getElementById("designation").onkeypress = function(e) {
    var chr = String.fromCharCode(e.which);
    if ("></\"=".indexOf(chr) >= 0)
        return false;
};

</script>
<?php include("footer.php")?>