<?php
include("../connection.php");
$id=$_REQUEST['id'];


$query="delete from master_class where id='$id'";
mysqli_query($conn,$query);
header("Location:class_all");
?>