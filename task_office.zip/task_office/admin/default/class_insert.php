<?php 
  include("../connection.php");
  ?>
  <?php

  if(isset($_POST['submit']))
  {
  extract($_POST);
  $file_name=$_FILES['file']['name'];
  $tmp_name=$_FILES['file']['tmp_name'];
  $location='../upload/';
  $heading=$_POST['heading'];
   $paragraph=$_POST['paragraph'];
   $links_create=$_POST['links_create'];
   $links_name=$_POST['links_name'];
   $date=$_POST['date'];  
  $query="insert into master_class(image,heading,paragraph,links_create,links_name,date) values('$file_name','$heading','$paragraph','$links_create','$links_name','$date')";
  mysqli_query($conn,$query);
  move_uploaded_file($tmp_name,$location.$file_name);
  echo "<script>alert('content has been added successfully');window.location.href='class_all';</script>";
  }
?>
