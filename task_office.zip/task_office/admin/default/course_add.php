<?php
 include "../connection.php";   
    session_start();
    if (!isset($_SESSION["userid"]))
    {
        header("Location:../index");
    }    
?>
<?php $page="course";include("header.php")?>
<!-- Main Content -->
<div class="adminx-content">
        <div class="adminx-main-content">
          <div class="container-fluid">
            <div class="pb-3">
              <h1><b><i>Course Name</i></b></h1>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <div class="card mb-grid">
                  <div class="card-body collapse show" id="card1">
                  <form action="course_insert" method="post" enctype="multipart/form-data">
                      <div class="form-group">
                        <label class="form-label" for="exampleInputPassword1">Course Name</label>
                        <input type="text" class="form-control" id="exampleInputPassword1" placeholder="Heading Of Links" name="course_name">
                      </div>
                      <!-- <div class="form-group">
                        <label class="form-label" for="exampleInputPassword1">Links Create</label>
                        <input type="text" class="form-control" id="exampleInputPassword1" placeholder="Links Create" name="links_create">
                      </div> -->
              <button type="submit" class="btn btn-sm btn-block btn-primary" name="submit">Create Course</button>
            </form>
            </div>
         </div>
<?php include("footer.php")?>