<?php 
  
  include("../connection.php");
  ?>
  
  <?php

  if(isset($_POST['submit']))
  {
  extract($_POST);
  $file_name=$_FILES['file']['name'];
  $tmp_name=$_FILES['file']['tmp_name'];
  $location='../upload/';
   $file_name_1=$_FILES['file_1']['name'];
  $tmp_name_1=$_FILES['file_1']['tmp_name_1'];
  $location='../upload/';
  $name=$_POST['name'];
 $query="insert into alumni(image,image_1,name) values('$file_name','$file_name_1','$name')";
  mysqli_query($conn,$query);
  move_uploaded_file($tmp_name,$location.$file_name);
  move_uploaded_file($tmp_name,$location.$file_name_1);
  echo "<script>alert('content has been added successfully');window.location.href='alumni_all';</script>";
  }
?>
