<?php
 include "../connection.php";   
    session_start();
    if (!isset($_SESSION["userid"]))
    {
        header("Location:../index");
    }    
?>
<?php
$id=$_REQUEST['id'];
$sq="select * from nav_links where id='$id'";
$q=mysqli_query($conn,$sq);
$fet=mysqli_fetch_assoc($q);

if(isset($_POST['upload'])){

   $links_create=$_POST['links_create'];
   $links_name=$_POST['links_name'];
     
       
     $sq1="UPDATE nav_links SET links_create='$links_create',links_name='$links_name' where id='$id'";

      if(mysqli_query($conn,$sq1)){
        echo '<script language="javascript">';
        echo 'alert("Your Content successfully Updated");';
        echo 'window.location.href="navbar_all";';
        echo '</script>';
        

     }else{
        echo '<script language="javascript">';
        echo 'alert("Your Content Is Not Updated");';
        echo 'window.location.href="navbar_all";';
        echo '</script>';
     }
      
   }
?>
<?php $page="navbar"; include("header.php")?>
<!-- Main Content -->
<div class="adminx-content">
        <div class="adminx-main-content">
          <div class="container-fluid">
            <div class="pb-3">
              <h1><b><i>Slider</i></b></h1>
            </div>

            <div class="row">
              <div class="col-lg-12">
                <div class="card mb-grid">
                  <div class="card-body collapse show" id="card1">
                  <form action="" method="post" enctype="multipart/form-data">
                      <div class="form-group">
                        <label class="form-label" for="exampleInputPassword1">Links_name</label>
                        <input type="text" class="form-control" id="exampleInputPassword1" placeholder="Links_name" name="links_name" value="<?php echo $fet['links_name'];?>">
                      </div>
                      <div class="form-group">
                        <label class="form-label" for="exampleInputPassword1">Links Create</label>
                        <input type="text" class="form-control" id="exampleInputPassword1" placeholder="paragraph" name="links_create" value="<?php echo $fet['links_create'];?>">
                      </div>
                      <button type="submit" class="btn btn-sm btn-block btn-primary" name="upload">Edit</button>
            </form>
            </div>
         </div>
         <script>
    
document.getElementById("heading").onkeypress = function(e) {
    var chr = String.fromCharCode(e.which);
    if ("></\"=".indexOf(chr) >= 0)
        return false;
};
document.getElementById("paragraph").onkeypress = function(e) {
    var chr = String.fromCharCode(e.which);
    if ("></\"=".indexOf(chr) >= 0)
        return false;
};
</script>
<?php include("footer.php")?>