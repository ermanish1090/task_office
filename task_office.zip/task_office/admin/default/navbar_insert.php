<?php 
  
  include("../connection.php");
  ?>
  
  <?php

  if(isset($_POST['submit']))
  {
  extract($_POST);
  
   $links_create=$_POST['links_create'];
   $links_name=$_POST['links_name'];
  
  $query="insert into nav_links(links_create,links_name) values('$links_create','$links_name')";
  mysqli_query($conn,$query);
  echo "<script>alert('Links has been added successfully');window.location.href='navbar_all';</script>";
  }
?>
