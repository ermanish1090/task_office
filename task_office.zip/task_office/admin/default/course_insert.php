<?php 
  
  include("../connection.php");
  ?>
  
  <?php

  if(isset($_POST['submit']))
  {
  extract($_POST);
  
   $course_name=$_POST['course_name'];
  
  $query="insert into course(course_name) values('$course_name')";
  mysqli_query($conn,$query);
  echo "<script>alert('Course has been added successfully');window.location.href='course_all';</script>";
  }
?>
