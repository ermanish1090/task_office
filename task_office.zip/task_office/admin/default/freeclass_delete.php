<?php
include("../connection.php");
$id=$_REQUEST['id'];


$query="delete from free_class where id='$id'";
mysqli_query($conn,$query);
header("Location:freeclass_all");
?>