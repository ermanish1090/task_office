<?php
 include "../connection.php";   
    session_start();
    if (!isset($_SESSION["userid"]))
    {
        header("Location:../index");
    }    
?>
<?php
$id=$_REQUEST['id'];
$sq="select * from slider where id='$id'";
$q=mysqli_query($conn,$sq);
$fet=mysqli_fetch_assoc($q);

if(isset($_POST['upload'])){
    $file =$_FILES['file']['name'];
    $file_loc = $_FILES['file']['tmp_name'];
     $file_size = $_FILES['file']['size'];
     $file_type = $_FILES['file']['type'];
     $folder="../upload/";
     if($file_loc)
     {
     move_uploaded_file($file_loc,$folder.$file);
     $headingtop=$_POST['headingtop'];
     $heading=$_POST['heading'];
      $paragraph=$_POST['paragraph'];
      $links_create=$_POST['links_create'];
      $links_name=$_POST['links_name'];
       
    $sq1="UPDATE slider SET heading='$heading',headingtop='$headingtop' paragraph='$paragraph',links_create='$links_create',links_name='$links_name',image='$file' where id='$id'";
      if(mysqli_query($conn,$sq1)){
        echo '<script language="javascript">';
        echo 'alert("Your Content successfully Updated");';
        echo 'window.location.href="all_slider";';
        echo '</script>';

     }else{
        echo '<script language="javascript">';
        echo 'alert("Your Content Is Not Updated");';
        echo 'window.location.href="all_slider";';
        echo '</script>';
     }
    }else{

    $headingtop=$_POST['headingtop'];
  $heading=$_POST['heading'];
   $paragraph=$_POST['paragraph'];
   $links_create=$_POST['links_create'];
   $links_name=$_POST['links_name'];
     
       
     $sq1="UPDATE slider SET heading='$heading',headingtop='$headingtop', paragraph='$paragraph',links_create='$links_create',links_name='$links_name' where id='$id'";

      if(mysqli_query($conn,$sq1)){
        echo '<script language="javascript">';
        echo 'alert("Your Content successfully Updated");';
        echo 'window.location.href="all_slider";';
        echo '</script>';
        

     }else{
        echo '<script language="javascript">';
        echo 'alert("Your Content Is Not Updated");';
        echo 'window.location.href="all_slider";';
        echo '</script>';
     }
      
   } 
}
?>
<?php $page="slider"; include("header.php")?>
<!-- Main Content -->
<div class="adminx-content">
        <div class="adminx-main-content">
          <div class="container-fluid">
            <div class="pb-3">
              <h1><b><i>Slider</i></b></h1>
            </div>

            <div class="row">
              <div class="col-lg-12">
                <div class="card mb-grid">
                  <div class="card-body collapse show" id="card1">
                  <form action="" method="post" enctype="multipart/form-data">
                      <div class="form-group">
                        <label class="form-label" for="exampleInputEmail1">HeadingTop Conents</label>
                        <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Heading Top Content" name="headingtop" value="<?php echo $fet['headingtop'];?>">
                      </div>
                      <div class="form-group">
                        <label class="form-label" for="exampleInputEmail1">Heading</label>
                        <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Heading" name="heading" value="<?php echo $fet['heading'];?>">
                      </div>
                      <div class="form-group">
                        <label class="form-label" for="exampleInputPassword1">Paragraph</label>
                        <input type="text" class="form-control" id="exampleInputPassword1" placeholder="paragraph" name="paragraph" value="<?php echo $fet['paragraph'];?>">
                      </div>
                      <div class="form-group">
                        <label class="form-label" for="exampleInputPassword1">Links_name</label>
                        <input type="text" class="form-control" id="exampleInputPassword1" placeholder="Links_name" name="links_name" value="<?php echo $fet['links_name'];?>">
                      </div>
                      <div class="form-group">
                        <label class="form-label" for="exampleInputPassword1">Links Create</label>
                        <input type="text" class="form-control" id="exampleInputPassword1" placeholder="paragraph" name="links_create" value="<?php echo $fet['links_create'];?>">
                      </div>
                      <div class="form-group">
                        <label class="form-label" for="exampleInputPassword1">Current Image</label><br>
                        <img src="../upload/<?php echo $fet['image'];?>" width="150" height="100"/>
                      </div>
                      <div class="form-group">
                        <label class="form-label" for="exampleInputPassword1">Upload Image</label>
                        <input type="file" class="form-control" id="exampleInputPassword1" name="file" accept="image/png, image/jpg, image/jpeg" value="<?php echo $fet['image'];?>">
                      </div>
                      <button type="submit" class="btn btn-sm btn-block btn-primary" name="upload">Edit</button>
            </form>
            </div>
         </div>
         <script>
    
document.getElementById("heading").onkeypress = function(e) {
    var chr = String.fromCharCode(e.which);
    if ("></\"=".indexOf(chr) >= 0)
        return false;
};
document.getElementById("paragraph").onkeypress = function(e) {
    var chr = String.fromCharCode(e.which);
    if ("></\"=".indexOf(chr) >= 0)
        return false;
};
</script>
<?php include("footer.php")?>