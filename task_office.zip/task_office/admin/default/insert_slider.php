<?php 
  
  include("../connection.php");
  ?>
  
  <?php

  if(isset($_POST['submit']))
  {
  extract($_POST);
  $file_name=$_FILES['file']['name'];
  $tmp_name=$_FILES['file']['tmp_name'];
  $location='../upload/';

  $headingtop=$_POST['headingtop'];
  $heading=$_POST['heading'];
   $paragraph=$_POST['paragraph'];
   $links_create=$_POST['links_create'];
   $links_name=$_POST['links_name'];
  
  $query="insert into slider(image,heading,paragraph,headingtop,links_create,links_name) values('$file_name','$heading','$paragraph','$headingtop','$links_create','$links_name')";
  mysqli_query($conn,$query);
  move_uploaded_file($tmp_name,$location.$file_name);
  echo "<script>alert('content has been added successfully');window.location.href='all_slider';</script>";
  }
?>
