<?php

$conn = mysqli_connect('localhost','root','','can_tech');
mysqli_select_db($conn,"can_tech");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }

?>